Json.NET's source code has moved to GitHub.
CodePlex was last updated March 7, 2012

https://github.com/JamesNK/Newtonsoft.Json